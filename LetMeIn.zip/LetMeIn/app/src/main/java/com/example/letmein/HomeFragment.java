package com.example.letmein;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment implements View.OnClickListener {

    private EditText TxtUsername, TxtPassword;
    private Button BtnAddUser, BtnReadUser;


    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        BtnAddUser = view.findViewById(R.id.btn_add_user);
        BtnAddUser.setOnClickListener(this);

        BtnReadUser = view.findViewById(R.id.btn_login);
        BtnReadUser.setOnClickListener(this);

        TxtUsername = view.findViewById(R.id.txt_username);
        TxtPassword = view.findViewById(R.id.txt_password);

        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){

            case R.id.btn_add_user:
            MainActivity.fragmentManager.beginTransaction().replace(R.id.fragment_container,new AddUserFragment()).
                    addToBackStack(null).commit();
            break;

            case R.id.btn_login:

                MainActivity.fragmentManager.beginTransaction().replace(R.id.fragment_container,new LandingPageFragment()).
                        addToBackStack(null).commit();

                break;
            }
        }
    }
